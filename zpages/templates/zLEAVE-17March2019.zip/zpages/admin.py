from django.contrib import admin

# Register your models here.

from .models import Department
from .models import DeptApprovers
from .models import StaffMaster
from .models import StaffUsers
from .models import PlaceOfWork

from .models import LvBalances
from .models import LvApplications

admin.site.register(Department)
admin.site.register(DeptApprovers)
admin.site.register(StaffMaster)
admin.site.register(StaffUsers)
admin.site.register(PlaceOfWork)

admin.site.register(LvBalances)
admin.site.register(LvApplications)
