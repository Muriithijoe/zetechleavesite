from django.apps import AppConfig


class ZpagesConfig(AppConfig):
    name = 'zpages'
