
# zpages/forms.py
from django import forms
from zpages.models import MyLvApps, LvSchedules

#class ContactForm(forms.Form):
#    from_email = forms.EmailField(required=True)
#    subject = forms.CharField(required=True)
#    message = forms.CharField(widget=forms.Textarea, required=True)
    

class ContactForm(forms.Form):
    myitem1 = forms.CharField(required=True)
    myitem2 = forms.CharField(required=True)


class LvApplyForm(forms.Form):
    staff_id = forms.CharField(required=True)
    lv_type = forms.CharField(required=True)
    
    myDate = forms.DateField(widget=forms.TextInput(attrs=
                                {
                                    'class':'datepicker'
                                }))
    myDate2 = forms.DateField(widget=forms.TextInput(attrs=
                                {
                                    'class':'datepicker'
                                }))

# Create the form class.
class LvScheduleForm(forms.ModelForm):
    class Meta:
        model = LvSchedules
        fields = ['staff_id', 'sched1_start', 'sched1_days', 'sched2_start', 'sched2_days'
                      ,'sched3_start', 'sched3_days', 'sched4_start', 'sched4_days', 'lv_description']
        
        widgets = {'sched1_start': forms.DateInput(attrs={'class': 'datepicker'}),
                   'sched2_start': forms.DateInput(attrs={'class': 'datepicker'}),
                   'sched3_start': forms.DateInput(attrs={'class': 'datepicker'}),
                   'sched4_start': forms.DateInput(attrs={'class': 'datepicker'})
                   }
        
    
    # Creating a form to add an article.
    #form = LvScheduleForm()

    # Creating a form to change an existing article.
    #article = Article.objects.get(pk=1)
    #form = ArticleForm(instance=article)
