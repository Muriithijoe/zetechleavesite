from django.db import models
from django.contrib.auth.models import User

# Create your models here.

class LvSchedules(models.Model):
   staff_id   = models.IntegerField() #not null auto_increment primary key,
   dept   = models.IntegerField()
   sched1_start  = models.DateField()
   sched1_days  = models.IntegerField(null=False)
   sched2_start  = models.DateField()
   sched2_days  = models.IntegerField(null=False)
   sched3_start  = models.DateField()
   sched3_days  = models.IntegerField(null=False)
   sched4_start  = models.DateField()
   sched4_days  = models.IntegerField(null=False)
   lv_description =  models.CharField(max_length=100)
   lv_remarks1 =  models.CharField(max_length=100)
   lv_remarks2 =  models.CharField(max_length=100)
   sched_status  = models.IntegerField(null=False)
   approver1_id  = models.IntegerField(null=False)
   approver2_id  = models.IntegerField(null=False)
   approver3_id  = models.IntegerField(null=False)  # ADD CancellER ID !!!
   approval1_dt  = models.DateField()
   approval2_dt  = models.DateField()
   approval3_dt  = models.DateField()
   returned_dt  = models.DateField()
   recheck  = models.IntegerField()
   return_user_id  = models.CharField(max_length=10)
   #FOREIGN KEY fk_appr1(approver3)
   #REFERENCES staffmaster(staff_id)
   #ON UPDATE CASCADE
   #ON DELETE RESTRICT


class MyLvApps(models.Model):
    myDate = models.DateField(blank=False)
    myDate2 = models.DateField(blank=False)

class Department(models.Model):
    dept_id = models.IntegerField()
    dept_name = models.CharField(max_length=50)
    created_at = models.DateField()
    approver1_id  = models.CharField(max_length=10)
    approver2_id  = models.CharField(max_length=10)
    approver3_id  = models.CharField(max_length=10)
    approver4_id  = models.CharField(max_length=10)

    def __str__(self):
        return self.dept_name

class DeptApprovers(models.Model):
   dept_id = models.IntegerField()
   dept_name = models.CharField(max_length=50)
   created_at = models.DateField()
   approver1_id  = models.CharField(max_length=10)
   approver2_id  = models.CharField(max_length=10)
   approver3_id  = models.CharField(max_length=10)
   approver4_id  = models.CharField(max_length=10)

class StaffMaster(models.Model):
	staff_id  = models.IntegerField()
	first_name = models.CharField(max_length=30)
	last_name = models.CharField(max_length=30)
	phone_number = models.CharField(max_length=30)
	email = models.CharField(max_length=30)
	id_number = models.CharField(max_length=30)
	position = models.CharField(max_length=30)
	contract_type  = models.IntegerField()
	job_grade  = models.IntegerField()
	dept_id  = models.IntegerField()
	appt_date = models.DateField()

	def __str__(self):
            return self.first_name

class StaffUsers(models.Model):
   staff_id  = models.IntegerField()    #not null auto_increment primary key,
   user_id = models.CharField(max_length=20)
   password = models.CharField(max_length=30)
   llogin_dt = models.DateField()
   login_attempts   = models.IntegerField()
   user_status   = models.IntegerField()

   def __str__(self):
        return self.user_id

class PlaceOfWork(models.Model):
   place_id  = models.IntegerField()    #not null auto_increment primary key,
   place_name = models.CharField(max_length=30)

   def __str__(self):
        return self.place_name

class LvBalances(models.Model):
   staff_id   = models.IntegerField() #not null auto_increment primary key,
   lv_annual  = models.IntegerField(null=False)
   lv_study  = models.IntegerField(null=False)
   lv_maternity  = models.IntegerField(null=False)
   lv_paternity  = models.IntegerField(null=False)
   lv_study  = models.IntegerField(null=False)
   lv_compassion  = models.IntegerField(null=False)
   lv_other  = models.IntegerField(null=False)
   lv_other2  = models.IntegerField(null=False)
   #FOREIGN KEY fk_appr1(approver3)
   #REFERENCES staffmaster(staff_id)
   #ON UPDATE CASCADE
   #ON DELETE RESTRICT


class LvApplications(models.Model):
   staff_id = models.IntegerField(null=False)   # auto_increment primary key,
   dept = models.IntegerField(null=False)
   first_name =  models.CharField(max_length=30)
   second_name =  models.CharField(max_length=30)
   lv_type  = models.IntegerField(null=False)
   lv_days = models.IntegerField(null=False)
   application_dt = models.DateField()
   approval1  = models.IntegerField(null=False)
   approval2  = models.IntegerField(null=False)
   approval3  = models.IntegerField(null=False)
   approver1_id  = models.IntegerField()
   approver2_id  = models.IntegerField()
   approver3_id  = models.IntegerField()  # ADD CancellER ID !!!
   approval1_dt  = models.DateField()
   approval2_dt  = models.DateField()
   approval3_dt  = models.DateField()
   cancelled_dt  = models.DateField()
   deducted   = models.IntegerField(null=False)
   cancelled  = models.IntegerField()
   #FOREIGN KEY fk_appr1(approver3)
   #REFERENCES staffmaster(staff_id)
   #ON UPDATE CASCADE
   #ON DELETE RESTRICT
   


