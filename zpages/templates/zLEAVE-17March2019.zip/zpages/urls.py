
# pages/urls.py
from django.urls import path

from .views import HomePageView, AboutPageView, defaultView, successView
from .views import lvApplications, lvApproval, lvApprovalDetail, lvBalance
from .views import lvScheduleShow, lvSchedApproval, lvSchedApprovalDetail
from .views import lvScheduleList, lvMySchedule, lvReports, lvCancel

from .views import lvCreateUsers, lvCentral, lvStaffSummary

urlpatterns = [
    path('', HomePageView.as_view(), name='home'),
    path('about', AboutPageView.as_view(), name='about'),
    path('defaultView/', defaultView, name='defaultView'),
    
    path('success/', successView, name='success'),
    path('lvApplied/', lvApplications, name='lvApplications'),
    
    path('lvApproval/', lvApproval, name='lvApproval'),
    path('lvApprovalDetail/', lvApprovalDetail, name='lvApprovalDetail'),
    path('lvCancel/', lvCancel, name='lvCancel'),
    
    path('lvCentral/', lvCentral, name='lvCentral'),
    path('lvBalance/', lvBalance, name='lvBalance'),
    path('lvStaffSummary/', lvStaffSummary, name='lvStaffSummary'),
    path('lvReports/', lvReports, name='lvReports'),

    path('lvScheduleList/', lvScheduleList, name='lvScheduleList'),
    path('lvMySchedule/', lvMySchedule, name='lvMySchedule'),
    path('lvScheduleShow/', lvScheduleShow, name='lvScheduleShow'),

    
    path('lvSchedApproval/', lvSchedApproval, name='lvSchedApproval'),
    path('lvSchedApprovalDetail/', lvSchedApprovalDetail, name='lvSchedApprovalDetail'),

    path('CreateUsers/', lvCreateUsers, name='lvCreateUsers'),
    
]
