
# pages/views.py
from django.views.generic import TemplateView
import datetime;

from django.core.mail import send_mail, BadHeaderError
from django.http import HttpResponse, HttpResponseRedirect
from django.shortcuts import render, redirect

from .forms import ContactForm, LvApplyForm, LvScheduleForm
from .models import Department, LvApplications, LvBalances, StaffMaster, StaffUsers, LvSchedules, User

myHolidays={"2019-03-04","2019-03-05","2019-03-06","2019-03-07"}

class HomePageView(TemplateView):
    template_name = 'home.html'

class AboutPageView(TemplateView):
    template_name = 'about.html'

def lvApplications(request):
    form = LvApplyForm()
    if request.method == 'GET':
        form = LvApplyForm()
    else:
        form = LvApplyForm(request.POST)
        if form.is_valid():
            myitem1 = form.cleaned_data['staff_id']
            myitem2 = form.cleaned_data['lv_type']
            myitem3 = form.cleaned_data['myDate']
            myitem4 = form.cleaned_data['myDate2']
            myitemx =(myitem4 - myitem3).days
            
            lvAppcant = LvBalances.objects.get(staff_id=myitem1)
            
            #if lvAppcant.lv_type >= myitem3:
            if lvAppcant.lv_annual >= 3:
                try:
                    myUser = StaffMaster.objects.get(staff_id = myitem1)
                    now=datetime.datetime.now()
                    
                    lvAppn = LvApplications(staff_id=myitem1,dept=3,first_name=myUser.first_name,second_name=myUser.last_name,
                                            lv_type=myitem2, lv_days=myitemx,application_dt=now.strftime("%Y-%m-%d"),
                                            approval1=9, approval2=9, approval3=9, 
                                            approver1_id=0, approver2_id=0,approver3_id=0,
                                            approval1_dt='2019-02-14',approval2_dt='2019-02-14',approval3_dt='2019-02-14',
                                            cancelled_dt='2019-02-14',deducted=0, cancelled=0)
                    lvAppn.save();
                    saveMsg="You Have Just Submitted A Leave Application. Notifications Will Be sent on Approvals"

                    #myLvApps = LvApplications.objects.filter(staff_id = uid)  
                    #myUser = StaffMaster.objects.get(staff_id = myitem1)
                    myLvBals = LvBalances.objects.get(staff_id = myitem1)  
                    lvApps = LvApplications.objects.filter(staff_id=myitem1)
                    lvApproveds = LvApplications.objects.filter(staff_id=myitem1, approval1=6)
                    form = LvApplyForm()

                    return render(request, 'LvApplications.html',{'lvApps': lvApps,'lvApproveds': lvApproveds,  'myLvBals':myLvBals, 'query': myUser,'form': form,'saveMsg':saveMsg})
                except BadHeaderError:
                    return HttpResponse('Invalid header found.')
                #return redirect('success')
                #return render(request, "LvApplications.html", {'form': form})

    uid = request.GET['user_id']            
    myUser = StaffMaster.objects.get(staff_id = uid)
    myLvBals = LvBalances.objects.get(staff_id = uid)  
    lvApps = LvApplications.objects.filter(staff_id=uid)
    lvApproveds = LvApplications.objects.filter(staff_id=uid, approval1=6)
    return render(request, 'LvApplications.html', {'lvApps': lvApps, 'lvApproveds': lvApproveds, 'myLvBals':myLvBals, 'query': myUser,'form': form})
    #return render(request, "lvApply.html", {'form': form})

def lvApproval(request):
    '''form = LvApplyForm()
    if request.method == 'GET':
        form = LvApplyForm()
    else:
        form = LvApplyForm(request.POST)
        if form.is_valid():
    
            myitem1 = form.cleaned_data['staff_id']
            myitem2 = form.cleaned_data['lv_type']
            myitem3 = form.cleaned_data['lv_days']
     '''
    try:
        if request.method == 'GET':

            #if request.GET['user_id']==201 | request.GET['user_id']==202 | request.GET['user_id']==203 :   
            uid = request.GET['user_id']
            lid = request.GET['id']

            if uid in ('201','202','203'):
                boss_lvl=9
            if uid in ('222'):
                boss_lvl=8
            if uid in ('233'):
                boss_lvl=7

            approvalMsg=''
            
            if uid and lid: 
                if lid > '0':
                    #lid = request.GET['id']
                    llvl = request.GET['lvl']

                    now=datetime.datetime.now()
                    
                    lvAppn = LvApplications.objects.get(id=lid)
                    mynow=now.strftime("%Y-%m-%d")
                    
                    if llvl=='1': lvAppn.approval1=8; lvAppn.approver1_id=uid; lvAppn.approval1_dt=mynow;
                    if llvl=='2': lvAppn.approval1=7; lvAppn.approver2_id=uid; lvAppn.approval2_dt=mynow;
                    if llvl=='3': lvAppn.approval1=6; lvAppn.approver3_id=uid; lvAppn.approval3_dt=mynow; lvAppn.deducted=1;
                    if llvl=='c': lvAppn.approval1=5; lvAppn.cancelled=1; lvAppn.cancelled_dt=mynow

                    lvAppn.save()
                    approvalMsg = 'You Have just Approved A Leave Application'
                    
        #BE CAREFUL to Improve Next Query
        #lvApps = LvApplications.objects.all()
        myUser = StaffMaster.objects.get(staff_id = uid)
        
        #lvApps = LvApplications.objects.filter(approval3=9) and LvApplications.objects.filter(lv_days__gt=4)
        lvApps = LvApplications.objects.filter(approval1=boss_lvl, cancelled=0) #and LvApplications.objects.filter(lv_days__gt=4)
        
        return render(request, 'LvApprovals.html',
                              {'lvApps': lvApps, 'query': 'All','user_id': uid, 'myUser':myUser,'boss_lvl':boss_lvl,'approvalMsg':approvalMsg})
    except BadHeaderError:
        #return HttpResponse('Invalid header found.')
        #return redirect('success')
        #return render(request, "LvApplications.html", {'form': form})
        return render(request, "lvApprovals.html", {'form': form})

def lvApprovalDetail(request):
    '''form = LvApplyForm()
    if request.method == 'GET':
        form = LvApplyForm()
    else:
        form = LvApplyForm(request.POST)
        if form.is_valid():
    
            myitem1 = form.cleaned_data['staff_id']
            myitem2 = form.cleaned_data['lv_type']
            myitem3 = form.cleaned_data['lv_days']
     '''
    try:
        if request.method == 'GET':

            #if request.GET['user_id']==201 | request.GET['user_id']==202 | request.GET['user_id']==203 :   
            uid = request.GET['user_id']
            lid = request.GET['id']
            saveMsg =''
            
            if uid and lid: 
                #lid = request.GET['id']
                llvl = request.GET['lvl']

                now=datetime.datetime.now()
                
                lvAppn = LvApplications.objects.get(id=lid)
                mynow=now.strftime("%Y-%m-%d")
                
                if llvl=='0': dummy=''
                if llvl=='1': lvAppn.approval1=8; lvAppn.approver1_id=uid; lvAppn.approval1_dt=mynow;
                if llvl=='2': lvAppn.approval1=7; lvAppn.approver2_id=uid; lvAppn.approval2_dt=mynow;
                if llvl=='3': lvAppn.approval1=6; lvAppn.approver3_id=uid; lvAppn.approval3_dt=mynow; lvAppn.deducted=1;
                if llvl=='c': lvAppn.approval1=5; lvAppn.cancelled=1; lvAppn.cancelled_dt=mynow
                           
                if llvl > '0':
                    lvAppn.save()
                    saveMsg="You Have Just MODIFIED A Leave Application"

        #BE CAREFUL to Improve Next Query
        #lvApps = LvApplications.objects.all()
        myUser = StaffMaster.objects.get(staff_id = uid)
        theAppn = LvApplications.objects.get(id=lid)
        theStaffBalances = LvBalances.objects.get(staff_id = theAppn.staff_id)
        theStaff = StaffMaster.objects.get(staff_id = theAppn.staff_id)
        
        #lvApps = LvApplications.objects.filter(approval3=9) and LvApplications.objects.filter(lv_days__gt=4)
        lvCancelleds = LvApplications.objects.filter(staff_id = theAppn.staff_id, cancelled=1)
        approvedLvs = LvApplications.objects.filter(staff_id = theAppn.staff_id, approval1=6)
        pendingLvs = LvApplications.objects.filter(staff_id = theAppn.staff_id, approval1__gt=6, cancelled=0)
        
        
        #return render(request, 'LvApprovalDetail.html',
        #                      {'lvApps': lvApps, 'theAppn': theAppn,'user_id': uid, 'myUser':myUser})
        return render(request, 'LvApprovalDetail.html',
                              {'pendingLvs': pendingLvs,'lvCancelleds': lvCancelleds,'approvedLvs': approvedLvs,
                               'theAppn': theAppn,'user_id': uid, 'myUser':myUser,'theStaff':theStaff, 'saveMsg': saveMsg,
                               'theStaffBalances':theStaffBalances})

    except BadHeaderError:
        #return HttpResponse('Invalid header found.')
        #return redirect('success')
        #return render(request, "LvApplications.html", {'form': form})
        return render(request, "lvApprovals.html", {'form': form})


def lvCancel(request):
    try:
        if request.method == 'GET':

            #if request.GET['user_id']==201 | request.GET['user_id']==202 | request.GET['user_id']==203 :   
            uid = request.GET['user_id']
            lid = request.GET['id']
            
            if uid and lid: 
                llvl = request.GET['lvl']

                now=datetime.datetime.now()
                lvAppn = LvApplications.objects.get(id=lid)
                mynow=now.strftime("%Y-%m-%d")
                
                if llvl=='c': lvAppn.cancelled=1; lvAppn.cancelled_dt=mynow
                           
                lvAppn.save()

        #BE CAREFUL to Improve Next Query
        #lvApps = LvApplications.objects.all()
        myUser = StaffMaster.objects.get(staff_id = uid)
        theAppn = LvApplications.objects.get(id=lid)
        lvApps = LvApplications.objects.filter(approval3=9) and LvApplications.objects.filter(lv_days__gt=4)
        return render(request, 'LvApprovalDetail.html',
                              {'lvApps': lvApps, 'theAppn': theAppn,'user_id': uid, 'myUser':myUser})
    except BadHeaderError:
        #return HttpResponse('Invalid header found.')
        #return redirect('success')
        #return render(request, "LvApplications.html", {'form': form})
        return render(request, "lvApprovals.html", {'form': form})

def lvBalance(request):
    try:
        lvBals = LvBalances.objects.all()
        return render(request, 'LvBalance.html',
                              {'lvBals': lvBals, 'query': 'All'})
    except BadHeaderError:
        return HttpResponse('Invalid header found.')
        #return redirect('success')
        #return render(request, "LvApplications.html", {'form': form})
    return render(request, "lvBalance.html", {'form': form})

def lvStaffSummary(request):
    try:
        if request.method == 'GET':

            #if request.GET['user_id']==201 | request.GET['user_id']==202 | request.GET['user_id']==203 :   
            uid = request.GET['user_id']
            #lid = request.GET['id']
            sid = request.GET['staff_id']
            
        #BE CAREFUL to Improve Next Query
        #lvApps = LvApplications.objects.all()
        myUser = StaffMaster.objects.get(staff_id = uid)
        theStaffBalances = LvBalances.objects.get(staff_id = sid)
        theStaff = StaffMaster.objects.get(staff_id = sid)
        
        #lvApps = LvApplications.objects.filter(approval3=9) and LvApplications.objects.filter(lv_days__gt=4)
        lvCancelleds = LvApplications.objects.filter(staff_id = sid, cancelled=1)
        approvedLvs = LvApplications.objects.filter(staff_id = sid, approval1=6)
        pendingLvs = LvApplications.objects.filter(staff_id = sid, approval1__gt=6, cancelled=0)
        theStaffSchedule = LvSchedules.objects.get(staff_id = sid)

        
        #return render(request, 'LvApprovalDetail.html',
        #                      {'lvApps': lvApps, 'theAppn': theAppn,'user_id': uid, 'myUser':myUser})
        return render(request, 'LvStaffSummary.html',
                              {'pendingLvs': pendingLvs,'lvCancelleds': lvCancelleds,'approvedLvs': approvedLvs,
                               'user_id': uid, 'myUser':myUser,'theStaff':theStaff, 'theStaffSchedule':theStaffSchedule, 
                               'theStaffBalances':theStaffBalances})

    except BadHeaderError:
        #return HttpResponse('Invalid header found.')
        #return redirect('success')
        #return render(request, "LvApplications.html", {'form': form})
        return render(request, "lvApprovals.html", {'form': form})


def lvCentral(request):
    try:
        #lvAllUsers = User.objects.all()
        uid = request.GET['user_id']
        lvAllUsers = StaffMaster.objects.all()
        
        return render(request, 'lvCentral.html',
                              {'lvAllUsers': lvAllUsers, 'boss_lvl':9, 'user_id': uid})
    except BadHeaderError:
        return HttpResponse('Invalid header found.')
        #return redirect('success')
        #return render(request, "LvApplications.html", {'form': form})
    return render(request, "lvCentral.html", {'form': form})


def defaultView(request):
    try:
        if request.method == 'GET':
            uid = request.GET['user_id']
            #llvl = request.GET['user_id2']

            myUser = StaffMaster.objects.get(staff_id = uid)  # BE CAREFUL WITH NOT EXISTING DATA
            myLvApps = LvApplications.objects.filter(staff_id = uid)  
            myLvBals = LvBalances.objects.get(staff_id = uid)   # BE CAREFUL WITH NOT EXISTING DATA

            exist_items = Department.objects.filter(approver1_id = uid)|Department.objects.filter(approver2_id = uid)|Department.objects.filter(approver3_id = uid)
            exist_topbrass = Department.objects.filter(approver3_id = uid)
            boss_count=exist_items.count()   # This person is an Approver
            topbrass_count=exist_topbrass.count()   # This person is an Approver
   
            if topbrass_count >= 1:
                lvApps = LvApplications.objects.filter(staff_id__gte=120)  # BE CAREFUL WITH GTE and LTE and LT and GT
                brass=1;
                return render(request, 'defaultView.html',
                                          {'user_id': uid,'lvApps': lvApps, 'myUser': myUser,'myLvApps': myLvApps,'myLvBals': myLvBals
                                           ,'brass': brass})

            if boss_count >= 1:
                lvApps = LvApplications.objects.filter(staff_id__gte=120)  # BE CAREFUL WITH GTE and LTE and LT and GT
                brass=2;
                
                return render(request, 'defaultView.html',
                                          {'user_id': uid,'lvApps': lvApps, 'myUser': myUser,'myLvApps': myLvApps,'myLvBals': myLvBals
                                           ,'brass': brass})
    except BadHeaderError:
        return HttpResponse('Invalid header found.')
        #return redirect('success')
        #return render(request, "LvApplications.html", {'form': form})

    myLvApps = LvApplications.objects.filter(staff_id = uid)  # BE CAREFUL WITH GTE and LTE and LT and GT
    myLvBals = LvBalances.objects.get(staff_id = uid)  
    myUser = StaffMaster.objects.get(staff_id = uid)
    
    # BE CAREFUL WITH GET Variable next line
    return render(request, "defaultView.html",
                  {'user_id': request.GET['user_id'], 'myUser': myUser,'myLvApps': myLvApps,'myLvBals': myLvBals})
    #use redirect to another template for those that are approvers


def lvReports(request):
    try:
        #lvBals = LvBalances.objects.all()

        xstaff_id  = request.GET['user_id']
        
        myUser = StaffMaster.objects.get(staff_id = xstaff_id)    # BE CAREFUL to update these lines of code
        theAppn = LvApplications.objects.get(id=23)
        theStaffBalances = LvBalances.objects.get(staff_id = 233)
        
        #lvApps = LvApplications.objects.filter(approval3=9) and LvApplications.objects.filter(lv_days__gt=4)
        lvCancelleds = LvApplications.objects.filter(staff_id = theAppn.staff_id, cancelled=1)
        approvedLvs = LvApplications.objects.filter(staff_id = theAppn.staff_id, approval1=6)
        pendingLvs = LvApplications.objects.filter(staff_id = theAppn.staff_id, approval1__gt=6, cancelled=0)
        # =============================
        myX=999;
        
        lvRpt = request.GET['lvRpt']
        if lvRpt=='1':
            lvApplicationList = LvApplications.objects.filter(approval1 = 9)     #lvAppliedThisMonth
            rptMessage ='Pending Approval Level 1'
            myX=1
        if lvRpt=='2':
            lvApplicationList = LvApplications.objects.filter(approval1 = 8)     #lvApprovedThisMonth
            rptMessage ='Pending Approval Level 2'
            myX=2
        if lvRpt=='3':
            lvApplicationList = LvApplications.objects.filter(approval1 = 7)     #lvApprovedThisMonth
            rptMessage ='Pending Approval Level 3'
            myX=3
        if lvRpt=='4':
            lvApplicationList = LvApplications.objects.filter(lv_type = 2)     #lvCancelledAMonth
            rptMessage ='Maternity Leave Applications'
            myX=4
        if lvRpt=='5':
            lvApplicationList = LvApplications.objects.filter(cancelled = 1)     #lvCancelledAMonth
            rptMessage ='Cancelled'
            myX=5
        if lvRpt=='6':
            lvApplicationList = LvApplications.objects.filter(lv_type = 3)     #lvCancelledAMonth
            rptMessage ='Paternity Leave Applications'
            myX=6
        if lvRpt=='9':
            lvtp=1 ; appvo1=9   # BE CAREFUL Get these from Variables POST from Search Form
            lvApplicationList = LvApplications.objects.filter(lv_type = lvtp,approval1 = appvo1)     #lvCancelledAMonth
            rptMessage ='Annual Leave Applications Waiting for 1ST Approval'
            myX=9

        if  myX <= 9:
            return render(request, 'lvRptsLeave.html', {'lvApplicationList': lvApplicationList ,'myUser':myUser,'lvRpt':lvRpt,'rptMessage':rptMessage})

        if lvRpt=='10':
            lvBalances = LvBalances.objects.filter(lv_annual__gte=14)     #Leave Balances
            rptMessage ='Balances Annual Leave More than 14'
            myX=10
        if lvRpt=='11':
            lvBalances = LvBalances.objects.filter(lv_annual__lte=5)     #Leave Balances
            rptMessage ='Balances Annual Less  Than 5'
            myX=11
        if lvRpt=='12':
            lvBalances = lvBalances.objects.filter(id__gte=1)           #Leave Balances
            rptMessage ='Balances Annual Leave More than 10'
            myX=12

        '''    
        if lvRpt==6:
            lvStaffList = StaffMaster.objects.filter(id__gte=1)     #StaffMaster
        if lvRpt==7:
            lvStaffList = StaffUsers.objects.filter(id__gte=1)     #StaffUsers
        '''
        
        #return render(request, 'LvReports.html', {'lvAppliedThisMonth': lvAppliedThisMonth,'lvApprovedThisMonth': lvApprovedThisMonth,'lvWaitingAMonth': lvWaitingAMonth,'lvCancelledAMonth': lvCancelledAMonth,'lvApprovedThisMonth': lvApprovedThisMonth,'query': 'All','lvRpt':lvRpt})
        return render(request, 'lvRptsLeave.html', {'lvBalances': lvBalances,'myUser':myUser , 'lvRpt':lvRpt, 'rptMessage':rptMessage})
    
    except BadHeaderError:
        return HttpResponse('Invalid header found.')
        #return redirect('success')
        #return render(request, "LvApplications.html", {'form': form})
    #return render(request, 'LvReports.html', {'lvBals': lvBals, 'query': 'All','lvRpt':lvRpt})
    return render(request, 'lvRptsLeave.html', {'lvApplicationList': lvApplicationList,'myUser':myUser, 'lvRpt':lvRpt, 'rptMessage':rptMessage})


def successView(request):
    return HttpResponse('Success! Thank you for your message.')

def date_by_adding_business_days(from_date, add_days, myHolidays):
    business_days_to_add = add_days
    current_date = from_date
    while business_days_to_add > 0:
        current_date += datetime.timedelta(days=1)
        weekday = current_date.weekday()
        if weekday >= 5: # sunday = 6
            continue
        if current_date in myHolidays:
            continue
        business_days_to_add -= 1
    return current_date


################################



def lvScheduleShow(request):
#def lvScheduleDo(request):
    #form = LvScheduleForm()
    if request.method == 'GET':
        form = LvScheduleForm()
    else:
        form = LvScheduleForm(request.POST)
        if form.is_valid():
            
            staffid = form.cleaned_data['staff_id']
            s1_start = form.cleaned_data['sched1_start']
            s2_start = form.cleaned_data['sched2_start']
            s3_start = form.cleaned_data['sched3_start']
            s4_start = form.cleaned_data['sched4_start']
            s1_days = form.cleaned_data['sched1_days']
            s2_days = form.cleaned_data['sched2_days']
            s3_days = form.cleaned_data['sched3_days']
            s4_days = form.cleaned_data['sched4_days']
            schedText = form.cleaned_data['lv_description']

            print ('GOT HERE IN LV SCHEDULE')
            
            #lvAppcant = LvBalances.objects.get(staff_id=staffid)
            x=7
            
            #if lvAppcant.lv_type >= myitem3:		# BE CAREFUL 
            if x >=5:    #lvAppcant.lv_annual >= 3:
                try:
                    lvSched = LvSchedules(staff_id=staffid, dept=3, sched1_start=s1_start, sched1_days=s1_days,
                                          sched2_start=s2_start, sched2_days=s2_days, sched3_start=s3_start,sched3_days=s3_days, 
                                          sched4_start=s4_start,sched4_days=s4_days,lv_description=schedText, lv_remarks1='blank', lv_remarks2='blank',
                                          sched_status=9, approver1_id=0, approver2_id=0,approver3_id=0,approval1_dt='2019-01-10',
                                          approval2_dt='2019-01-10',approval3_dt='2019-01-10',recheck=0, returned_dt='2019-02-14', return_user_id='222')
                    
                    lvSched.save();
                    saveMsg="You Have Just Submitted A Leave Schedule. Notifications Will Be sent on Approvals"

                    #myLvScheds = LvSchedule.objects.filter(staff_id = uid)  
                    myUser = StaffMaster.objects.get(staff_id = staffid)
                    lvScheds = LvSchedules.objects.filter(staff_id=staffid)
                    form = LvScheduleForm()

                    return render(request, 'lvMyScheduleShow.html',{'lvScheds': lvScheds, 'query': myUser,'form': form,'saveMsg':saveMsg})
                except BadHeaderError:
                    return HttpResponse('Invalid header found.')
                #return redirect('success')
                #return render(request, "LvSchedule.html", {'form': form})

    #uid = request.POST['staff_id']            
    uid = request.GET['user_id']       
    myUser = StaffMaster.objects.get(staff_id = uid)        #BECAREFUL 
    lvScheds = LvSchedules.objects.filter(staff_id=uid)     #BECAREFUL 
    #return render(request, 'LvSchedule.html', {'lvScheds': lvScheds, 'query': myUser,'form': form})
    return render(request, 'lvMyScheduleShow.html', {'lvScheds': lvScheds, 'query': myUser,'form': form})


def lvSchedApproval(request):
    '''form = LvScheduleForm()
    if request.method == 'GET':
        form = LvScheduleForm()
    else:
        form = LvScheduleForm(request.POST)
        if form.is_valid():
    
            myitem1 = form.cleaned_data['staff_id']
            myitem2 = form.cleaned_data['lv_type']
            myitem3 = form.cleaned_data['lv_days']
     '''
    try:
        if request.method == 'GET':

            #if request.GET['user_id']==201 | request.GET['user_id']==202 | request.GET['user_id']==203 :   
            uid = request.GET['user_id']
            
            #if request.GET['id'] > 0:
            lid = request.GET['id']

            if uid in ('201','202','203'):     #BE CAREFUL
                boss_lvl=9
            if uid in ('222'):
                boss_lvl=8
            if uid in ('233'):
                boss_lvl=7

            schedApprovalMsg=''		# BE CAREFUL
            
            if uid and lid: 
                if lid > '0':
                    #lid = request.GET['id']
                    llvl = request.GET['lvl']

                    now=datetime.datetime.now()
                    
                    lvSched = LvSchedules.objects.get(id=lid)
                    mynow=now.strftime("%Y-%m-%d")
                    
                    if llvl=='1': lvSched.sched_status=8; lvSched.approver1_id=uid; lvSched.approval1_dt=mynow;
                    if llvl=='2': lvSched.sched_status=7; lvSched.approver2_id=uid; lvSched.approval2_dt=mynow;
                    if llvl=='3': lvSched.sched_status=6; lvSched.approver3_id=uid; lvSched.approval3_dt=mynow; lvSched.deducted=1;
                    if llvl=='c': lvSched.sched_status=5; lvSched.recheck=1; lvSched.returned_dt=mynow

                    lvSched.save()
                    schedApprovalMsg = 'You Have just Approved A Leave Schedule'
                    
        #BE CAREFUL to Improve Next Query
        #lvScheds = LvSchedule.objects.all()
        myUser = StaffMaster.objects.get(staff_id = uid)
        
        #lvScheds = LvSchedule.objects.filter(approval3=9) and LvSchedule.objects.filter(lv_days__gt=4)
        lvScheds = LvSchedules.objects.filter(sched_status=boss_lvl, recheck=0) #and LvSchedule.objects.filter(lv_days__gt=4)
        
        return render(request, 'LvSchedApproval.html',
                              {'lvScheds': lvScheds, 'query': 'All','user_id': uid, 'myUser':myUser,'boss_lvl':boss_lvl,'schedApprovalMsg':schedApprovalMsg})
    except BadHeaderError:
        #return HttpResponse('Invalid header found.')
        #return redirect('success')
        #return render(request, "LvSchedule.html", {'form': form})
        return render(request, "lvSchedApproval.html", {'form': form})


def lvSchedApprovalDetail(request):
    '''form = LvScheduleForm()
    if request.method == 'GET':
        form = LvScheduleForm()
    else:
        form = LvScheduleForm(request.POST)
        if form.is_valid():
    
            myitem1 = form.cleaned_data['staff_id']
            myitem2 = form.cleaned_data['lv_type']
            myitem3 = form.cleaned_data['lv_days']
     '''
    try:
        if request.method == 'GET':

            #if request.GET['user_id']==201 | request.GET['user_id']==202 | request.GET['user_id']==203 :   
            uid = request.GET['user_id']
            lid = request.GET['id']
            saveMsg =''
            
            if uid in ('201','202','203'):     #BE CAREFUL
                boss_lvl=9
            if uid in ('222'):
                boss_lvl=8
            if uid in ('233'):
                boss_lvl=7
            
            if uid and lid: 
                #lid = request.GET['id']
                llvl = request.GET['lvl']

                now=datetime.datetime.now()
                
                lvSched = LvSchedules.objects.get(id=lid)
                mynow=now.strftime("%Y-%m-%d")
                
                if llvl=='0': dummy=''
                if llvl=='1': lvSched.sched_status=8; lvSched.approver1_id=uid; lvSched.approval1_dt=mynow;
                if llvl=='2': lvSched.sched_status=7; lvSched.approver2_id=uid; lvSched.approval2_dt=mynow;
                if llvl=='3': lvSched.sched_status=6; lvSched.approver3_id=uid; lvSched.approval3_dt=mynow;
                if llvl=='c': lvSched.sched_status=5; lvSched.recheck=1; lvSched.returned_dt=mynow
                           
                if llvl > '0':
                    lvSched.save()
                    saveMsg="You Have Just MODIFIED A Leave Schedule"

        #BE CAREFUL to Improve Next Query
        uid = request.GET['user_id']
        lid = request.GET['id']
        myUser = StaffMaster.objects.get(staff_id = uid)
        #theStaff = LvSchedules.objects.get(id=lid)
        theStaffSchedule = LvSchedules.objects.filter(id = lid)
        theStaff = StaffMaster.objects.get(staff_id = theStaffSchedule[0].staff_id)
        
        allStaffScheds = LvSchedules.objects.filter(staff_id = theStaff.staff_id)
        theStaffBalances = LvBalances.objects.get(staff_id = theStaff.staff_id)
        
        #return render(request, 'LvApprovalDetail.html',
        #                      {'lvApps': lvApps, 'theStaff': theStaff,'user_id': uid, 'myUser':myUser})
        return render(request, 'LvSchedApprovalDetail.html', {'allStaffScheds': allStaffScheds,'theStaffBalances': theStaffBalances,
                               'theStaff': theStaff,'user_id': uid, 'myUser':myUser,'theStaff':theStaff, 'saveMsg': saveMsg,
                               'theStaffSchedule':theStaffSchedule[0], 'boss_lvl':boss_lvl})

    except BadHeaderError:
        #return HttpResponse('Invalid header found.')
        #return redirect('LvSchedSuccess')
        #return render(request, "LvSchedule.html", {'form': form})
        return render(request, "LvSchedApprovalDetail.html", {'form': form})

def lvScheduleCancel(request):
    try:
        if request.method == 'GET':

            #if request.GET['user_id']==201 | request.GET['user_id']==202 | request.GET['user_id']==203 :   
            uid = request.GET['user_id']
            lid = request.GET['id']
            
            if uid and lid: 
                llvl = request.GET['lvl']

                now=datetime.datetime.now()
                lvSched = LvSchedule.objects.get(id=lid)
                mynow=now.strftime("%Y-%m-%d")
                
                if llvl=='c': lvSched.cancelled=1; lvSched.cancelled_dt=mynow
                           
                lvSched.save()

        #BE CAREFUL to Improve Next Query
        #lvApps = LvApplications.objects.all()
        myUser = StaffMaster.objects.get(staff_id = uid)
        theSched = LvSchedule.objects.get(id=lid)
        lvScheds = LvSchedule.objects.filter(approval3=9) and LvSchedule.objects.filter(lv_days__gt=4) # BE CAREFUL
        return render(request, 'LvScheduleDetail.html',
                              {'lvScheds': lvScheds, 'theSched': theSched,'user_id': uid, 'myUser':myUser})
    except BadHeaderError:
        #return HttpResponse('Invalid header found.')
        #return redirect('success')
        return render(request, "lvSchedApproval.html", {'form': form})

def lvScheduleList(request):
    try:
        uid = request.GET['user_id']

        if uid in ('201','202','203'):
            boss_lvl=9
        if uid in ('222'):
            boss_lvl=8
        if uid in ('233'):
            boss_lvl=7

        approvalMsg=''
        
        lvScheds = LvSchedules.objects.all().order_by('-sched_status','staff_id')
        lvSchedsLvl1 = LvSchedules.objects.filter(sched_status=9, recheck=0) # BE CAREFUL
        lvSchedsLvl2 = LvSchedules.objects.filter(sched_status=8, recheck=0) # BE CAREFUL
        lvSchedsLvl3 = LvSchedules.objects.filter(sched_status=7, recheck=0) # BE CAREFUL
        lvSchedsCdd = LvSchedules.objects.filter(recheck=1) # BE CAREFUL

        return render(request, 'LvScheduleList.html',
                                      {'lvScheds': lvScheds, 'lvSchedsLvl1': lvSchedsLvl1,
                                       'lvSchedsCdd': lvSchedsCdd, 'boss_lvl':boss_lvl,'user_id': uid})
        #return render(request, 'lvSchedule.html', {'form': form})
            
    except BadHeaderError:
        return HttpResponse('Invalid header found.')
        #return redirect('success')

    return render(request, "lvScheduleList.html", {'form': form})

def lvMySchedule(request):
    #if request.method == 'GET':
    #    form = LvScheduleForm()
    #else:
    #    form = LvScheduleForm(request.POST)
    #    if form.is_valid():

    try:
        if request.method == 'GET':

            #if request.GET['user_id']==201 | request.GET['user_id']==202 | request.GET['user_id']==203 :   
            uid = request.GET['user_id']
            
            myUser = StaffMaster.objects.get(staff_id = uid)
            lvScheds = LvSchedules.objects.filter(staff_id=uid)
            lvSchedsCdd = LvSchedules.objects.filter(recheck=1) # BE CAREFUL

            return render(request, 'LvMySchedule.html',
                                      {'lvScheds': lvScheds, 'lvSchedsCdd': lvSchedsCdd,'query':myUser})
            #return render(request, 'lvSchedule.html', {'form': form})
            
    except BadHeaderError:
        return HttpResponse('Invalid header found.')
        #return redirect('success')

    return render(request, "lvMySchedule.html", {'form': form})

def lvCreateUsers(request):
    try:
        if request.method == 'GET':
            
            #lvStaff = StaffMaster.objects.filter(staff_id__lte=105, id__gte=15)
            lvStaff = StaffMaster.objects.filter(staff_id__gte=106)

            for myStaff in lvStaff:    
                myUser = User(password='fd87g5w67ae35j543',last_login='1900-01-01',is_superuser=0,
                                    username='LV_ZU/'+ str(myStaff.staff_id),first_name=myStaff.first_name, last_name=myStaff.last_name,
                                    email=myStaff.email, is_staff=0,is_active=0,date_joined='1900-01-01')
                
                myUser.set_password('password99')                    
                myUser.save()           #BE CAREFUL , Duplicates Cause Faulure

            saveMsg="You Have Just Submitted User Creation Action"
            return render(request, 'lvCreateUsers.html')
            
    except BadHeaderError:
        return HttpResponse('Invalid header found.')
        #return redirect('success')

    return render(request, "lvCreateUsers.html", {'form': form})

